from django.shortcuts import render
from registration . forms import student_form,Employee_form
from registration . models import student_model,Employee_model
# Create your views here.


def registration_form(request):
    if request.method=='POST':
        fm = student_form(request.POST)
        if fm.is_valid():
            name = fm.cleaned_data['name']
            f_name = fm.cleaned_data['f_name']
            postal_add = fm.cleaned_data['postal_add']
            gender = fm.cleaned_data['gender']
            city = fm.cleaned_data['city']
            course = fm.cleaned_data['course']
            district = fm.cleaned_data['district']
            state= fm.cleaned_data['state']
            pincode = fm.cleaned_data['pincode']
            email = fm.cleaned_data['email']
            DOB = fm.cleaned_data['DOB']
            M_no = fm.cleaned_data['M_no']
            md = student_model(name=name,f_name=f_name,postal_add=postal_add,gender=gender,city=city,course=course,district=district,state=state,pincode=pincode,email=email,DOB=DOB,M_no=M_no)
            md.save()
    else:
        fm = student_form()
    return render(request,'index.html',{'form':fm})

def display(request):
    fm = student_model.objects.all()
    return render(request,'display.html',{'form':fm})


def employee(request):
    if request.method == 'POST':
        fm = Employee_form(request.POST)
        if fm.is_valid():
            empid = fm.cleaned_data['empid']
            name = fm.cleaned_data['name']
            email = fm.cleaned_data['email']
            M_no = fm.cleaned_data['M_no']
            gender = fm.cleaned_data['gender']
            postal_add = fm.cleaned_data['postal_add']
            md = Employee_model(empid=empid,name=name,email=email,M_no=M_no,gender=gender,postal_add=postal_add)
            md.save()
    else:
        fm = Employee_form()
    return render(request,'employee.html',{'form':fm})


def emp_disp(request):
    fm=Employee_model.objects.all()
    return render(request,'emp_disp.html',{'form':fm})