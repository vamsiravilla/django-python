from django.db import models

# Create your models here.



class student_model(models.Model):
    name = models.CharField(max_length=20)
    f_name = models.CharField(max_length=20)
    postal_add = models.TextField()
    gender_choices = (
        ('male','male'),
        ('female','female'),
    )

    gender = models.CharField(max_length=10,choices=gender_choices)
    city_choices = (

        ('hyderabad', 'Hyderabd'),
        ('Bengaluru', 'Bengaluru'),
        ('chenni', 'chenni'),
        ('chenni', 'chenni')
    )

    city = models.CharField(max_length=10,choices=city_choices,default=1)


    course_choices = (

        ('python','Python'),
        ('django','Django'),
        ('java','java'),
        ('mysql','Mysql')
    )

    course = models.CharField(max_length=10,choices=course_choices)

    district_choices = (

        ('kurnool','kurnool'),
        ('Rangareddy','Rangareddy'),
        ('kadapa','kadapa'),
        ('anatnhapur','anatnhapur')
    )

    district = models.CharField(max_length=10,choices=district_choices,default=1)

    state_choices = (

        ('AP', 'AP'),
        ('TS', 'TS'),
        ('Tamilnadu', 'Tamilnadu'),
        ('karnataka', 'karnataka')
    )

    state = models.CharField(max_length=10,choices=state_choices,default=1)

    pincode = models.IntegerField()
    email = models.EmailField()
    DOB = models.DateField()
    M_no = models.IntegerField()


class Employee_model(models.Model):
    empid = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=20)
    email = models.EmailField()
    M_no = models.IntegerField()
    gender_choices = (
        ('male', 'male'),
        ('female', 'female'),
    )

    gender = models.CharField(max_length=10,choices=gender_choices)
    postal_add = models.TextField()