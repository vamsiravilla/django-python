from django.contrib import admin
from registration . models import student_model,Employee_model
# Register your models here.
admin.site.register(student_model)

admin.site.register(Employee_model)