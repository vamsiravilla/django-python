from django import forms


class student_form(forms.Form):
    name = forms.CharField(max_length=20)
    f_name = forms.CharField(max_length=20)
    postal_add = forms.CharField(widget=forms.Textarea)
    gender_choices = (
        ('male','male'),
        ('female','female'),
    )

    gender = forms.ChoiceField(choices=gender_choices)
    city_choices = (

        ('hyderabad','Hyderabd'),
        ('Bengaluru','Bengaluru'),
        ('chenni','chenni'),
        ('chenni','chenni')
    )

    city = forms.ChoiceField(choices=city_choices)

    course_choices = (

        ('python','Python'),
        ('django','Django'),
        ('java','java'),
        ('mysql','Mysql')
    )

    course = forms.ChoiceField(choices=course_choices)

    district_choices = (

        ('kurnool','kurnool'),
        ('Rangareddy','Rangareddy'),
        ('kadapa','kadapa'),
        ('anatnhapur','anatnhapur')
    )

    district = forms.ChoiceField(choices=district_choices)

    state_choices = (

        ('AP', 'AP'),
        ('TS', 'TS'),
        ('Tamilnadu', 'Tamilnadu'),
        ('karnataka', 'karnataka')
    )

    state = forms.ChoiceField(choices=state_choices)

    pincode = forms.IntegerField()
    email = forms.EmailField()
    DOB = forms.DateField()
    M_no = forms.IntegerField()



class Employee_form(forms.Form):
    empid = forms.IntegerField()
    name = forms.CharField(max_length=20)
    email = forms.EmailField()
    M_no = forms.IntegerField()
    gender_choices = (
        ('male', 'male'),
        ('female', 'female'),
    )

    gender = forms.ChoiceField(choices=gender_choices)
    postal_add = forms.CharField(widget=forms.Textarea)