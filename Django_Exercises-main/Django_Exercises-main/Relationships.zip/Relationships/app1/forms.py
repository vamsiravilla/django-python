from django.forms import ModelForm
from app1.models import Menu,Item


class Menu_form(ModelForm):
    class Meta:
        model = Menu
        fields = '__all__'


class Item_form(ModelForm):
    class Meta:
        model = Item
        fields = '__all__'