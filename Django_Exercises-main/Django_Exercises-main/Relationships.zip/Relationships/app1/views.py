from django.shortcuts import render
from app1.models import Menu,Item,Amenity,Store
from app1.forms import Menu_form,Item_form

# Create your views here.
def one_to_one(request):
    data1 = Menu.objects.all()
    data2 = Item.objects.all()
    data3 = Amenity.objects.all()
    data4 = Store.objects.all()
    return render(request,'one.html',{'data1':data1,'data2':data2,'data3':data3,'data4':data4})