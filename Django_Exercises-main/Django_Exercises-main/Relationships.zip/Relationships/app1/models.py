from django.db import models

# Create your models here.
#####################   ONE-TO-MANY-RELATIONSHIP  ###########################

class Menu(models.Model):
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class Item(models.Model):
    menu = models.OneToOneField(Menu,on_delete=models.CASCADE)
    name = models.CharField(max_length=30)
    description = models.CharField(max_length=100)


########################## MANY-TO-MANY-RELATIONSHIP #######################################

class Amenity(models.Model):
    name = models.CharField(max_length=30)
    description = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Store(models.Model):
    amenities = models.ManyToManyField(Amenity,related_name='models')
    name = models.CharField(max_length=30)
    address = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    state = models.CharField(max_length=2)
    email = models.EmailField()


########################## ONE-TO-ONE-RELATIONSHIP #######################################



class Menu1(models.Model):
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class Item1(models.Model):
    menu = models.ForeignKey(Menu,on_delete=models.CASCADE)
    name = models.CharField(max_length=30)
    description = models.CharField(max_length=100)
    calories = models.IntegerField()
    price = models.FloatField()

class Drink(models.Model):
    item = models.OneToOneField(Item,on_delete=models.CASCADE,primary_key=True)
    caffeine = models.IntegerField()
