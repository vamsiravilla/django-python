from django.contrib import admin
from app1.models import Menu,Item,Amenity,Store,Menu1,Item1,Drink

# Register your models here.

@admin.register(Menu)
class Menu_admin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Item)
class Item_admin(admin.ModelAdmin):
    list_display = ['menu','name','description']


########################## MANY-TO-MANY-RELATIONSHIP #######################################

@admin.register(Amenity)
class amenity_admin(admin.ModelAdmin):
    list_display = ['name','description']



@admin.register(Store)
class store_admin(admin.ModelAdmin):
    list_display = ['name','address','city','state','email']


########################## ONE-TO-ONE-RELATIONSHIP #######################################



@admin.register(Menu1)
class Menu1_admin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Item1)
class Item1_admin(admin.ModelAdmin):
    list_display = ['menu','name','description','calories','price']

@admin.register(Drink)
class Drink_admin(admin.ModelAdmin):
    list_display = ['item','caffeine']
