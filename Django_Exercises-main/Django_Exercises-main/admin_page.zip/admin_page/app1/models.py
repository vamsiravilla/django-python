from django.db import models

# Create your models here.
class Employee(models.Model):
    eid = models.IntegerField(primary_key=True)
    ename = models.CharField(max_length=20)
    emob = models.IntegerField(unique=True)
    email = models.EmailField()
    eadd = models.TextField()

class Student(models.Model):
    sid = models.IntegerField(primary_key=True)
    sname = models.CharField(max_length=20)
    smob = models.IntegerField(unique=True)
    semail = models.EmailField()
    sadd = models.TextField()
class Department(models.Model):
    did = models.IntegerField(primary_key=True)
    dname = models.CharField(max_length=20)
    dmob = models.IntegerField(unique=True)
    dadd = models.TextField()
def __str__(self):
    return str(self.ename)
