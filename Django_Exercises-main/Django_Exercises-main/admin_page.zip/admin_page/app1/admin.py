from django.contrib import admin
from .models import Employee,Student,Department
# Register your models here.
admin.site.register(Employee)
admin.site.register(Student)
admin.site.register(Department)
