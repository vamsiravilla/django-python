from django.shortcuts import render
from app1.models import Employee,Student,Department
# Create your views here.
def admin_page(request):
    data = Employee.objects.all()
    return render(request,'employee.html',{'data':data})


def stu_page(request):
    data=Student.objects.all()
    return render(request,'student.html',{'data':data})


def dep_page(request):
    data = Department.objects.all()
    return render(request,'department.html',{'data':data})