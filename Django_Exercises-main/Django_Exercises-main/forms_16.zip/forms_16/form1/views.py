from django.shortcuts import render
from .forms import student_form

# Create your views here.
def form_page(request):
    fm = student_form()
    return render(request,'form_page.html',{'form':fm})