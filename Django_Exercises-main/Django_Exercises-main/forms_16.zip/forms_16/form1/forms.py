from django import forms


class student_form(forms.Form):
    name = forms.CharField()
    id = forms.IntegerField()
    mno = forms.IntegerField()
    add = forms.CharField(widget=forms.Textarea)