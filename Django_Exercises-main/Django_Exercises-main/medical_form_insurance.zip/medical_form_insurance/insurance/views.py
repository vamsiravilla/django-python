from django.shortcuts import render
from insurance . forms import Medical_insurance_form

# Create your views here.
def medical(request):
    if request.method=='POST':
        fm = Medical_insurance_form(request.POST)
        if fm.is_valid():
            Hospital_name = fm.cleaned_data['Hospital_name']
            name = fm.cleaned_data['name']
            age = fm.cleaned_data['age']
            gender = fm.cleaned_data['gender']
    else:
        fm = Medical_insurance_form()
    return render(request,'medical.html',{'form':fm})