from django import forms

class Medical_insurance_form(forms.Form):
    error_css_class = 'error'
    required_css_class = 'required'
    Hospital_name = forms.CharField(max_length=20,help_text='Please Enter hospital name',initial='Hospital',error_messages={'required':'ENter hospital name'},label='Hospital')
    name = forms.CharField(max_length=20,help_text='Please Enter your fullName',initial='Name',error_messages={'required':'Please Enter your name'},label='name')
    age = forms.IntegerField()
    gender_choices = (
        ('male','Male'),
        ('female','female'),
    )

    gender = forms.ChoiceField(choices = gender_choices,widget=forms.RadioSelect)
    email = forms.EmailField(max_length=20, help_text='Please Enter your Email', initial='Name',error_messages={'required': 'Please Enter your Email'}, label='name')
