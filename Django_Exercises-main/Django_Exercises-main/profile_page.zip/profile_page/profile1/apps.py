from django.apps import AppConfig


class Profile1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'profile1'
